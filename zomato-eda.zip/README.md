# Zomato EDA & Insights

An exploratory data analysis (EDA) project on a Zomato restaurant dataset. It includes:
- Clean, reproducible Python code for loading, cleaning, and analyzing the dataset
- Ready-to-run visuals and summary stats
- A generated HTML report (`reports/Zomato-report.html`) exported from a Jupyter notebook

> Place your raw CSV (e.g., `Zomato-data-.csv`) inside `data/raw/` before running the scripts.

## Project Structure

```
zomato-eda/
├─ src/
│  ├─ eda.py                # main EDA script
│  └─ utils.py              # helper functions
├─ data/
│  ├─ raw/                  # put Zomato-data-.csv here
│  └─ processed/            # cleaned/derived datasets
├─ notebooks/               # (optional) your notebooks
├─ reports/
│  ├─ figures/              # charts saved here
│  └─ Zomato-report.html    # exported HTML report
├─ .github/workflows/       # CI pipeline (lint)
├─ .gitignore
├─ LICENSE
├─ requirements.txt
└─ README.md
```

## Quickstart

```bash
# 1) Create & activate a virtual environment (recommended)
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

# 2) Install dependencies
pip install -r requirements.txt

# 3) Put your dataset
#   e.g., Zomato-data-.csv -> data/raw/Zomato-data-.csv

# 4) Run the EDA
python -m src.eda --input data/raw/Zomato-data-.csv --outdir reports/figures --save-clean data/processed/zomato_clean.csv
```

This will print summary statistics to the console and save charts in `reports/figures/`.

## Dataset Expectations

The analysis expects a CSV with columns similar to:
- `name`
- `online_order` (Yes/No)
- `book_table` (Yes/No)
- `rate` (e.g., `4.1/5`)
- `votes` (int)
- `approx_cost(for two people)` (int/str)
- `listed_in(type)` (category)

You can customize column names through CLI flags.

## Reproduce the HTML Report

Open `reports/Zomato-report.html` in a browser to see an exported notebook. To regenerate your own report:
1. Start Jupyter: `jupyter notebook`
2. Create a new notebook in `notebooks/`
3. Run your analysis and export as HTML: *File → Download as → HTML*

## CLI Usage

```bash
python -m src.eda --help
```

## License

MIT — see `LICENSE`.