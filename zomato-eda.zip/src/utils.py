import re
import pandas as pd

def parse_rate(rate_str):
    """Convert '4.1/5' -> 4.1 (float). Returns NaN if not parseable."""
    if pd.isna(rate_str):
        return float('nan')
    m = re.match(r"\s*([0-9]*\.?[0-9]+)\s*/\s*5\s*", str(rate_str))
    return float(m.group(1)) if m else float('nan')

def clean_cost(value):
    """Convert '800' or '800.0' or '800 ' -> 800 (int)."""
    try:
        value = str(value).strip().replace(',', '')
        return int(float(value))
    except Exception:
        return None

def normalize_yes_no(x):
    """Normalize Yes/No variants to True/False."""
    s = str(x).strip().lower()
    if s in {"yes", "y", "true", "1"}:
        return True
    if s in {"no", "n", "false", "0"}:
        return False
    return None