import argparse
import os
import pandas as pd
import matplotlib.pyplot as plt

from .utils import parse_rate, clean_cost, normalize_yes_no

def load_data(csv_path):
    df = pd.read_csv(csv_path)
    return df

def clean_data(df,
               name_col="name",
               online_col="online_order",
               book_col="book_table",
               rate_col="rate",
               votes_col="votes",
               cost_col="approx_cost(for two people)",
               type_col="listed_in(type)"):
    # copy
    df = df.copy()
    # rename for convenience
    df = df.rename(columns={
        name_col: "name",
        online_col: "online_order",
        book_col: "book_table",
        rate_col: "rate",
        votes_col: "votes",
        cost_col: "approx_cost_for_two",
        type_col: "listed_in_type",
    })
    # parsing
    df["rate_num"] = df["rate"].map(parse_rate)
    df["online_order_bool"] = df["online_order"].map(normalize_yes_no)
    df["book_table_bool"] = df["book_table"].map(normalize_yes_no)
    df["approx_cost_for_two_num"] = df["approx_cost_for_two"].map(clean_cost)

    return df

def basic_charts(df, outdir):
    os.makedirs(outdir, exist_ok=True)

    # Votes distribution
    plt.figure()
    df["votes"].dropna().plot(kind="hist", bins=30, title="Votes Distribution")
    plt.xlabel("votes")
    plt.ylabel("frequency")
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, "votes_hist.png"))
    plt.close()

    # Ratings distribution
    plt.figure()
    df["rate_num"].dropna().plot(kind="hist", bins=20, title="Ratings (out of 5)")
    plt.xlabel("rating (0-5)")
    plt.ylabel("frequency")
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, "ratings_hist.png"))
    plt.close()

    # Cost vs Rating scatter
    plt.figure()
    sub = df.dropna(subset=["approx_cost_for_two_num", "rate_num"]).copy()
    plt.scatter(sub["approx_cost_for_two_num"], sub["rate_num"], alpha=0.5)
    plt.xlabel("Approx cost for two (INR)")
    plt.ylabel("Rating (out of 5)")
    plt.title("Cost vs Rating")
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, "cost_vs_rating.png"))
    plt.close()

def summarize(df):
    lines = []
    lines.append("Rows: {} | Columns: {}".format(df.shape[0], df.shape[1]))
    lines.append("\nColumns:\n  - " + "\n  - ".join(df.columns.astype(str)))
    lines.append("\nNumeric summary:\n{}".format(df.describe(include="number").to_string()))
    return "\n".join(lines)

def main():
    p = argparse.ArgumentParser(description="Zomato EDA")
    p.add_argument("--input", required=True, help="Path to Zomato CSV file")
    p.add_argument("--outdir", default="reports/figures", help="Directory to save figures")
    p.add_argument("--save-clean", default=None, help="Optional path to save cleaned CSV")    
    # optional custom column names
    p.add_argument("--name-col", default="name")
    p.add_argument("--online-col", default="online_order")
    p.add_argument("--book-col", default="book_table")
    p.add_argument("--rate-col", default="rate")
    p.add_argument("--votes-col", default="votes")
    p.add_argument("--cost-col", default="approx_cost(for two people)")
    p.add_argument("--type-col", default="listed_in(type)")
    args = p.parse_args()

    df = load_data(args.input)
    print("Loaded:", args.input)
    print(summarize(df))

    df_clean = clean_data(
        df,
        name_col=args.name_col,
        online_col=args.online_col,
        book_col=args.book_col,
        rate_col=args.rate_col,
        votes_col=args.votes_col,
        cost_col=args.cost_col,
        type_col=args.type_col,
    )
    print("\nAfter cleaning:")
    print(df_clean[["name","online_order_bool","book_table_bool","rate_num","votes","approx_cost_for_two_num","listed_in_type"]].head())

    basic_charts(df_clean, args.outdir)

    if args.save_clean:
        os.makedirs(os.path.dirname(args.save_clean), exist_ok=True)
        df_clean.to_csv(args.save_clean, index=False)
        print("Saved cleaned CSV to:", args.save_clean)

if __name__ == "__main__":
    main()